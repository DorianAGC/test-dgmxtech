## Levantar aplicacion backend

1.-Abrir una terminal, posicionarse en carpeta backend, ejecutar npm install 
2.-escribir el comando node index.js
