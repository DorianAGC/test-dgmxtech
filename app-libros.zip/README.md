# AppLibros


1.-Comando para levantar la aplicacion: ng serve
2.-Ruta front: http://localhost:4200


Angular: 19.2.13
Node : 20.13.1
